
import sqlite3

# Connect to SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Read SQL commands from setup.sql
with open('setup.sql', 'r') as f:
    sql_script = f.read()

# Execute SQL script
cursor.executescript(sql_script)

# Commit and close
conn.commit()
conn.close()

print("✅ Database initialized successfully!")
